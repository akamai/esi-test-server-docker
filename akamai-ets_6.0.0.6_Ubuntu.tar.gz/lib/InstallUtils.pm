#!/usr/bin/perl -w

use strict;
use Cwd;
use File::Basename;
use Time::Local;

my $true = "1";
my $false = "";

my $DASHED_LINE = "-----------------------------------------------------------------------------\n";

# Path to installer script and config scripts
my $esi_config_script = "ets_config";

my $home = $ENV{"HOME"};

#########################################################################
# detect_prefix: find the installation path to use

sub detect_prefix {
	my $def_prefix = shift;
    my $absfile = Cwd::abs_path( $0 );
	my $is_config = ( $0 =~ m/$esi_config_script$/ );
	
	if ( $absfile =~ m/\/bin\/[^\/]+$/ ) {
		return dirnam(dirname($absfile));
	}
	
    return $def_prefix;
}


#########################################################################
# get-consent: Dispalys a license agreement and prompts the user to
#                  either accept and continue, or decline and quit.
#

sub get_consent {
    print "\n\nPlease type \"yes\" to accept terms, or \"no\" to quit: ";
    my($answer) = "";
    while($true) {
		$answer = <STDIN>;
		chomp $answer;
		if($answer eq "yes") {
			return $true;
		} elsif ($answer eq "no") {
			return $false;
		} else {
			print "\nInvalid response. Please type \"yes\" to accept terms, or \"no\" to quit: ";
		}
    }
}

#########################################################################
# print_agreement: To print the ETS license agreement.
#

sub print_agreement {
    my($answer);
	
    my @parts = (
"  By downloading software (\"Software\") of Akamai Technologies, Inc.
  (\"Akamai\") from this site, you agree to the terms and conditions
  contained in this License Agreement (the \"Agreement\").  Please read this
  Agreement carefully before downloading or attempting to download this
  Software.  Akamai will license the Software to you only if you first accept
  the terms of this Agreement.  By downloading the Software, you agree to
  these terms.  If you do not agree to the terms of this Agreement, do not
  download the Software.
  
  The Software includes computer programs (machine-readableinstructions,
  data, and related documentation). The Software is owned by Akamai and
  is copyrighted and licensed and not sold.
  
  1. License.  You have a non-exclusive, personal and non-transferable
  license to use the Software solely in connection with Akamai EdgeSuite
  Services.  You will ensure that anyone who uses the Software does so
  only in compliance with the terms of this Agreement.
\nPlease press <Enter> to continue.\n\n",
  
"  2. Restrictions. You may not use, copy, modify or distribute the Software
  except as provided in this Agreement. Except as permitted byapplicable
  law and this Agreement, you may not decompile, reverse engineer,
  disassemble, modify, rent, lease, loan, distribute,sublicense, or
  create derivative works from, the Software or transmit the Software over
  a network. You may not use or otherwise export the Software except as
  authorized by United States law and the laws of the jurisdiction in
  which the Software was obtained. In particular, but without limitation,
  none of the Software may be used or otherwise exported or reexported (a)
  into (or to a national or resident of) a United States embargoed country
  or (b) to anyone on the U.S. Treasury Department\'s list of Specially
  Designated Nationals or the U.S. Department of Commerce\'s Table of
  Denial Orders. By using the Software, you represent and warrant that you
  are not located in, under control of, or a national or resident of any
  country or on any such list.
\nPlease press <Enter> to continue.\n\n",

"  3. No Warranty On Software. You use the Software entirely at your own
  risk. Akamai is providing the Software to you \"AS IS\" and without
  warranty. You are not entitled to any hard copy documentation, maintenance,
  support or updates for the Software.

  AKAMAI EXPRESSLY DISCLAIMS ALL WARRANTIES RELATED TO THE SOFTWARE, EXPRESS
  OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
  MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. AKAMAI DOES NOT WARRANT
  THAT THE FUNCTIONS CONTAINED IN THE SOFTWARE WILL MEET YOUR REQUIREMENTS, OR
  THAT THE OPERATION OF THE SOFTWARE WILL BE UNINTERRUPTED OR ERROR-FREE, OR
  THAT DEFECTS IN THE SOFTWARE WILL BE CORRECTED.  FURTHERMORE, AKAMAI DOES NOT
  WARRANT OR MAKE ANY REPRESENTATIONS REGARDING THE USE OR THE RESULTS OF THE
  USE OF THE SOFTWARE OR RELATED DOCUMENTATION IN TERMS OF THEIR CORRECTNESS,
  ACCURACY, RELIABILITY OR OTHERWISE. SOME JURISDICTIONS DO NOT ALLOW THE
  EXCLUSION OF IMPLIED WARRANTIES, SO PORTIONS OF THE ABOVE EXCLUSION MAY NOT
  APPLY TO YOU.
\nPlease press <Enter> to continue.\n\n",
	  
"  4. Limitation Of Liability. In no event shall Akamai be liable to you for any
  damages exceeding the amount paid for the Software.

  UNDER NO CIRCUMSTANCES, INCLUDING NEGLIGENCE, SHALL AKAMAI BE LIABLE FOR ANY
  INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES ARISING OUT OF OR
  RELATING TO THIS LICENSE, INCLUDING, BUT NOT LIMITED TO, DAMAGES RESULTING
  FROM ANY LOSS OF DATA CAUSED BY THE SOFTWARE. SOME JURISDICTIONS DO NOT ALLOW
  THE LIMITATION OF INCIDENTAL OR CONSEQUENTIAL DAMAGES SO THIS LIMITATION MAY
  NOT APPLY TO YOU.
\nPlease press <Enter> to continue.\n\n",

"  5. Government End Users. If you are acquiring the Software on behalf of any
  part of the United States Government, the following provisions apply. The
  Software and accompanying documentation are deemed to be \"commercial computer
  software\" and \"commercial computer software documentation,\" respectively,
  pursuant to DFAR Section 227.7202 and FAR 12.212(b), as applicable. Any use,
  modification, reproduction, release, performance, display or disclosure of
  the Software and/or the accompanying documentation by the U.S. Government or
  any of its agencies shall be governed solely by the terms of this Agreement
  and shall be prohibited except to the extent expressly permitted by the terms
  of this Agreement. Any technical data provided that is not covered by the
  above provisions is deemed to be \"technical data-commercial items\" pursuant
  to DFAR Section 227.7015(a). Any use, modification, reproduction, release,
  performance, display or disclosure of such technical data shall be governed
  by the terms of DFAR Section 220.7015(b).
\nPlease press <Enter> to continue.\n\n",

"  6. Controlling Law and Severability. This Agreement shall be governed by the
  laws of the United States and The Commonwealth of Massachusetts. If for any
  reason a courtof competent jurisdiction finds any provision, or portion
  thereof, to be unenforceable, the remainder of this Agreement shall continue
  in full force and effect. Any dispute regarding this Agreement shall be
  resolved in either the state or federal courts in Massachusetts.

  7. Complete Agreement. This Agreement constitutes the entire agreement between
  the parties with respect to the subject matter hereof and supersedes all
  prior or contemporaneous understandings regarding such subject matter. No
  amendment to or modification of this Agreement will be binding unless in
  writing.
		  
  8. Included in this software package is code from third parties.  Such code
  is licensed under its own terms and conditions which, by installing and using
  the Software you also hereby agree to abide by as follow.

  Certain code licensed under the Apache License, Version 2.0 (the \"License\");
  you may not use this file except in compliance with the License. You may
  obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
\nPlease press <Enter> to continue.\n\n",
	
"  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an \"AS IS\" BASIS, WITHOUT
  WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
  License for the specific language governing permissions and limitations under
  the License.
		
  libcurl Copyright (c) 1996 - 2013, Daniel Stenberg, <daniel\@haxx.se>.
  All rights reserved.
		
  Permission to use, copy, modify, and distribute this software for any purpose
  with or without fee is hereby granted, provided that the above copyright
  notice and this permission notice appear in all copies.
			
  THE SOFTWARE IS PROVIDED \"AS IS\", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT OF THIRD PARTY RIGHTS.
  IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
  OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE
  OR OTHER DEALINGS IN THE SOFTWARE.
\nPlease press <Enter> to continue.\n\n",
			
"  Except as contained in this notice, the name of a copyright holder shall not
  be used in advertising or otherwise to promote the sale, use or other
  dealings in this Software without prior written authorization of the copyright
  holder.
	  
  Your rights under this Agreement will terminate automatically without notice
  if you fail to comply with any term(s) of this Agreement.
");
				
	my $last = pop @parts;
	print "\n";
    print "LICENSE AGREEMENT\n\n";
	foreach my $part (@parts) {
		print $part;
		$answer = <STDIN>;
	}
	print $last;
}

#########################################################################
# get_input: A function to get input string from stdin.
# Input    : Default value of the string, an input string for prompt display,
#            a help string describing what's being asked.

sub get_input {
	
    my($def_input) = shift;
    my($input_string) = shift;
    my($help_string) = shift;
	
    my $input;
	
    print "\n\n";
    print "$help_string";
	
    print "$input_string [$def_input]: ";
    $input = <STDIN>;
    chomp($input);
	
    if ($input eq "") {
        $input = $def_input;
    }
	
    return $input;
}


#########################################################################
# welcome_message: A function to display a welcome and a description
#                  message
#

sub welcome_message {
	
    my($msg) = shift;
    print "\n";
    print $DASHED_LINE;
    print $msg;
    print $DASHED_LINE;
}

#########################################################################
# fix_prefix: Translates prefix to absolute path
#

sub fix_prefix {
    my($prefix) = shift;
    my($here) = getcwd();
    my($homepath) = $home;
	
    if($prefix =~ /\~\//) {
        $prefix =~ s/\~/$home/;
    } elsif ($prefix =~ /\~/) {
        $homepath =~ s/(.*)\/.*/$1/;
        $prefix =~ s/\~(.*)\//$homepath\/$1\//;
		
    } elsif ($prefix =~ /\./) {
		$prefix =~ s/\.\//$here\//;
    } elsif ($prefix =~ /^[^\/]/) {
		$prefix = $here . "/" .$prefix;
    }
	
    return $prefix;
	
}


#########################################################################
# success_message: To print infroamtion on starting, restarting, stopping
#                  and reconfiguring the server
#

sub success_message {
    my($prefix) = shift;
    my($esi_config_script) = shift;
	
    print "\n-  To start ETS at a later time, use the command:\n   " .
	"$prefix/bin/apachectl start\n";
    print "\n-  To restart ETS, use the command:\n   " .
	"$prefix/bin/apachectl restart\n";
    print "\n-  To stop ETS, use the command:\n   " .
	"$prefix/bin/apachectl stop\n";
    print "\n-  To reconfigure ETS, use the command:\n   $prefix/bin/$esi_config_script\n\n";
}

#########################################################################
# verify_start: To verify whether the server has successfully started
#               based on server log file, by calling find_server_start
#               subroutine
# Input       : Path to installed ETS server
# Output      : Return true if srver started, false otherwise
#

sub verify_start {
    my ($ESIPath) = shift;
    my($start) = time();
	
    my($mday, $mon, $year);
	
    my($starttime);
    my($started) = 0;
	
    if( -e "$ESIPath/logs/error_log") {
		
        for (1..10) {
			
            $starttime = find_server_start($ESIPath);
			
            if ($starttime >= $start) {
                ++$started;
                last;
            } else {
                sleep(1);
            }
        }
    }
	
    return $started;
}

#########################################################################
# find_server_start: Reads date of the lates server successfull start,
#                    from the server log file. It loops throught the file
#                    during a period of twenty seconds.
# Input            : Path to the server
# Output           : Start time in seconds or zere if there is no entry
#                    indicating a server start after the current time
#

sub find_server_start {
    my($path) = shift;
    my($log) = "$path/logs/error_log";
    my $line;
	
    my(%months) = ("Jan", "1", "Feb", "2", "Mar", "3", "Apr", "4",
	"May", "5", "Jun", "6", "Jul", "7", "Aug", "8",
	"Sep", "9", "Oct", "10", "Nov", "11", "Dec" , "12");
	
    open (LOG, "$log") || die "Unable to open $log: $!\n";
	
	
    foreach $line (reverse <LOG>) {
		
        if ($line =~ /\[[a-z]+\W([a-z]{3})\W((\s|\d)\d)\W([0-9]{2}):([0-9]{2}):([0-9]{2})\W([0-9]{4})\]\W.*\Wresuming\Wnormal\Woperations/i) {
			
            my($month) = $months{$1} -1;
            my($day) = $2;
            my($hour) = $4;
			
            my($min) = $5;
            my($sec) = $6;
            my($year) = $7 - 1900;
			
            my($logtime) = timelocal($sec, $min, $hour, $day, $month, $year);
			
            close (LOG);
            return $logtime;
        }
    }
}



sub verify_stop {
    my ($ESIPath) = shift;
    my($stop) = time();
	
    my($mday, $mon, $year);
	
    my($stoptime);
    my($stopped) = 0;
	
    if( -e "$ESIPath/logs/error_log") {
        for (1..2) {
			
            $stoptime = find_server_stop($ESIPath);
			
            if ($stoptime >= $stop) {
                ++$stopped;
                last;
            } else {
                sleep(1);
            }
        }
    }
	
    return $stopped;
}

sub find_server_stop {
    my($path) = shift;
    my($log) = "$path/logs/error_log";
    my $line;
	
    my(%months) = ("Jan", "1", "Feb", "2", "Mar", "3", "Apr", "4",
	"May", "5", "Jun", "6", "Jul", "7", "Aug", "8",
	"Sep", "9", "Oct", "10", "Nov", "11", "Dec" , "12");
    open (LOG, "$log") || die "Unable to open $log: $!\n";
	
	
    foreach $line (reverse <LOG>) {
		if ($line =~ /\[[a-z]+\W([a-z]{3})\W((\s|\d)\d)\W([0-9]{2}):([0-9]{2}):([0-9]{2})\W([0-9]{4})\]\W.*\Wcaught\WSIGTERM,\Wshutting\Wdown/i) {
			my($month) = $months{$1} -1;
			my($day) = $2;
			my($hour) = $4;
			
			my($min) = $5;
			my($sec) = $6;
			my($year) = $7 - 1900;
			
			my($logtime) = timelocal($sec, $min, $hour, $day, $month, $year);
			
			close (LOG);
			return $logtime;
        }
    }
}

#########################################################################
# fix_configs: A function that takes user input as arguments, and fixes
#              the pre-built apache httpd.conf file. It does the following:
#              - Fixes origin host
#              - Fixes origin port
#              - Fixes esi  port
#              - Modifies ESIDebuging flag
# Input      : ETS home directory, origin host, origin port, esi host port, prefix to apache
#              server ESIDebugging flag
# Output     : none
#

sub fix_configs {
	
    my $ETSHome = shift;

    my @user_input = @_;
    my @vhosts = ();
	
	my $tmpl_file = "$ETSHome/conf/esi.conf.tmpl";
	my $conf_file = "$ETSHome/conf/esi.conf";
	
	my $debug_stmt = $user_input[0]{debug_flag}? "ESIDebugging on" : "ESIDebugging off";
	my $geo_stmt = $user_input[0]{geo_flag}? $user_input[0]{geo_string} : "#Geo";
	my $apache_extra_config = $user_input[0]{apache_config}? $user_input[0]{apache_config} : "";
	
	system( "sed " .
	"-es%SUBST_PREFIX_SUBST%$ETSHome%g " .
	"-es%SUBST_PORT1_SUBST%$user_input[0]{port}%g " .
	"-es%SUBST_PORT2_SUBST%$user_input[0]{port2}%g " .
	"-es%SUBST_NAME2_SUBST%$user_input[0]{name}%g " .
	"\"-es%SUBST_DEBUG_SUBST%$debug_stmt%g\" " .
	"\"-es%SUBST_GEO_SUBST%$geo_stmt%g\" " .
	"\"-es%SUBST_APACHE_EXTRA_CONFIG%$apache_extra_config%g\" " .
	" < $tmpl_file > $conf_file"
	);
	
	create_maps( $ETSHome, @user_input );

	my $viewsource_tmpl = "$ETSHome/virtual/localhost/docs/esi-examples/utils/viewsource.html.tmpl";
	if(-s $viewsource_tmpl) {
	    system( "sed " .
	    "-es%SUBST_PORT2_SUBST%$user_input[0]{port2}%g " .
	    " < $viewsource_tmpl > $ETSHome/virtual/localhost/docs/esi-examples/utils/viewsource.html"
	    );
	}

	my $playground_conf = "$ETSHome/conf/esi_local_playground.conf.tmpl";
	if(-s $playground_conf) {
        my $geo_value  = $geo_stmt;
        if (index($geo_stmt, "GEO ") == 0) {
            $geo_value  = substr($geo_stmt, 4);
        } else {
            #just for sanity, expecting that GEO is always set, to some default value at least
            $geo_value  = "georegion=246,country_code=US,region_code=CA,city=SANJOSE,dma=807,pmsa=7400,areacode=408,county=SANTACLARA,fips=06085,lat=37.3353,long=-121.8938,timezone=PST,network_type=dialup";
        }

        system( "sed " .
        "-es%SUBST_GEO_SUBST%$geo_value%g " .
        " < $playground_conf > $ETSHome/conf/esi_local_playground.conf"
        );
    }
}

#########################################################################
# create_maps: A function that creates apache config files for each
#              configured origin host
# Input      : ETS home dir, list of origin hosts
# Output     : none
#

sub create_maps {
    my $ETSHome = shift;
    my @user_input = @_;
    shift @_;
    my @all_hosts = @_;
	
	my $tmpl_file = "$ETSHome/conf/esi_map.conf.tmpl";
    my $host = {};
	
	system( "rm -f $ETSHome/conf/esi_map_*.conf" );
	my $position = 0;
	foreach $host (@all_hosts) {
		if ($host->{status} ne "d") {
			my $conf_file = "${ETSHome}/conf/esi_map_${position}.conf";
			my $scheme = ($host->{port} eq 443)? "https" : "http";

			my $debug_stmt = $host->{debug_flag}? "ESIDebugging on" : "ESIDebugging off";
			my $geo_stmt = $host->{geo_flag}? $host->{geo_string} : "#Geo";
			my $apache_extra_config = $host->{apache_config}? $host->{apache_config} : "";
			
			$position++;

			system( "sed " .
			"-es%SUBST_PREFIX_SUBST%$ETSHome%g " .
			"-es%SUBST_PORT_SUBST%$user_input[0]{port}%g " .
			"-es%SUBST_ORIGIN_PORT_SUBST%$host->{port}%g " .
			"-es%SUBST_ORIGIN_NAME_SUBST%$host->{name}%g " .
			"-es%SUBST_ORIGIN_SCHEME_SUBST%$scheme%g " .
			"\"-es%SUBST_DEBUG_SUBST%$debug_stmt%g\" " .
			"\"-es%SUBST_GEO_SUBST%$geo_stmt%g\" " .
			"\"-es%SUBST_APACHE_EXTRA_CONFIG%$apache_extra_config%g\" " .
			" < $tmpl_file > $conf_file"
			);
		}
	}
}
