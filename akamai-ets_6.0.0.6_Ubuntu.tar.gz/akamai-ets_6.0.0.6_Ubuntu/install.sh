#/bin/sh

check_ubuntu() {

	NEEDED_PKGS=""
        ARCHITECTURE=$(uname -m)
	case "$ARCHITECTURE" in
	x86_64)
		echo "64-bit system, check if i386 compatibility layer is installed"
		NEEDED_PKGS="libc6:i386 libncurses5:i386 libstdc++6:i386"
		;;
	*)
		NEEDED_PKGS=""
		;;
	esac

	missing=""
	for pkg in $NEEDED_PKGS; do
		dpkg --get-selections | egrep "\\s+install$" | fgrep "$pkg" > /dev/null
		if [ $? -ne 0 ]; then
			missing="$missing $pkg$ARCH_EXT"
		fi
	done

	if [ "$missing" != "" ]; then
		if [ "$ARCHITECTURE" = "x86_64" ]; then
			echo "installing i386 compatibility layer"
			sudo dpkg --add-architecture i386
			sudo apt-get update
		fi
		echo "installing the following missing packages: $missing"
		sudo apt-get install -y $missing
	fi
}

distro=$( lsb_release -is )

case "$distro" in
Ubuntu)
	check_ubuntu
	;;
*)
	echo "unsupported linux distribution $distro"
	exit 1
	;;
esac


export PERL5LIB=./lib
perl lib/install.pl "$@"
