#!/usr/bin/perl -w

#########################################################################
# install.pl: A script to install and reconfigure ESI Test Server
#
# Usage  : install
#

use Cwd;
use Time::Local;
use InstallUtils;
use OriginHosts;
use Getopt::Long;
use Geo;

use constant { TRUE => 1, FALSE => 0 };

my $headless_install = FALSE;

GetOptions (
    "headless" => \$headless_install
) or die("Error in args.");

$config_file = "";

# Path to installer script and config scripts
$esi_config_script = "ets-config";
$esi_installer = "install";
$install_bindist = "./install-bindist.sh";
$files = "../files";

%geo = ('georegion', "246",
'country_code', "US",
'region_code', "CA",
'city', "SANJOSE",
'dma', "807",
'pmsa', "7400",
'areacode', "408",
'county', "SANTACLARA",
'fips', "06085",
'lat', "37.3353",
'long', "121.8938",
'timezone', "PST",
'network_type', "dialup"
);

#$geo_string = build_geo_string(%geo);


$home = $ENV{"HOME"};

sub usage {
	print "\n\tUsage: $0\n";
	exit (2);
}

# Print Usage message
if ($0 =~ /$esi_installer/) {
	if($#ARGV >= 0){
		usage();
	}
}


$def_prefix = "/opt/akamai-ets";

# Path to installed ETS directory. used to reoconfigure the server
$ETSHome = detect_prefix( $def_prefix );
# is_reconfig is true iff script is called as *config
$is_reconfig = ($0 =~ /.*\/\w+-config$/  || $0 =~ /^[^\/](.*)-config$/);

prep_ets_home();

if ( $headless_install ) {
	print "Headless install. Deferring configuration.\n";
	install_bindist();
	exit;
}

if ( $is_reconfig ) {
    welcome_message("ETS, The ESI Test Server, Configuration Program\n");
	print "\nModify httpd configuration...\n";
    
	@user_input = reconfig_prompt( get_settings() );
	fix_configs($ETSHome, @user_input);
}
else {
    welcome_message("ETS, The ESI Test Server, Installation Program\n");
	
    print_agreement();
    $consent = get_consent();
    if (!$consent) {
		print "\nYou declined to accept ETS license agreement....\nExiting ETS installation program...\n\n";
		exit 0;
    }
	
	my $config_exists = ( -d "$ETSHome" && -f "$ETSHome/conf/esi.conf" );
	# Get input from user
	@user_input = reconfig_prompt( $config_exists? get_settings() : ({
		"port" => 80, "name" => "localhost", "port2" => 81
	}));
	
	# Install apache package
	install_bindist();
	fix_configs($ETSHome, @user_input);
}


start_server();


################################################################################
# make certain we have a valid combination of install/reconfigure and check
# existing $ETSHome
#
sub prep_ets_home {
	if ( !-d $ETSHome ) {
		if ( -e $ETSHome ) {
			print "ETS home $ETSHome\nexists, but is not a directory. Please move it aways.\n";
			exit(1);
		}
		elsif ( !-w dirname($ETSHome) ) {
			print "Parent dir of $ETSHome\nis not writable. Maybe you need to run this script via sudo?\n";
			exit(1);
		}
		elsif ( $is_reconfig ) {
			print "ETS reconfiguration, but no ETS installation\nwas found at $ETSHome.\n";
			exit(1);
		}
	}
	else {
		if ( !-w $ETSHome ) {
			print "ETS home $ETSHome\nis not writable. Maybe you need to run this script via sudo?\n";
			exit(1);
		}
		if ( !$is_reconfig ) {
			while (1) {
				print "\nPrevious ETS installation exists at $ETSHome\n";
				print "Do you want to continue installation? [y|n] ";
				$answer = <STDIN>;
				chomp($answer);
				
				if($answer eq "y" || $answer eq "yes") {
					system "$ETSHome/bin/apachectl stop 1>/dev/null 2>&1";
					if (-e "${ETSHome}.old") {
						system "rm -rf ${ETSHome}.old";
					}
					last;
				} elsif ($answer eq "n" || $answer eq "no") {
					print "\nExiting ETS installation program....\n\n";
					exit (0);
				} else {
					print "\nInvalid response....\n ";
				}
			}
		}
	}
}

sub get_map_settings {
    my @user_input = @_;
    my @map_files = <$ETSHome/conf/esi_map_*.conf>;
	
	foreach $map_file (@map_files) {
		my %host = ( name => "", port => 80, debug_flag => 0 );
		my $in_vhost = 0;
		my ($geo_string, $geo_flag);
		$geo_flag = 0;
		
		open(CONFIG_FILE, "< $map_file")  || die "Can not open $map_file: $!\n";
		while (<CONFIG_FILE>) {
			
			if(/^\s*<VirtualHost\s+\*\:\S+>\s*$/) {
				$in_vhost = 1;
			}
			elsif (/^\s*<\/VirtualHost>\s*$/) {
				$in_vhost = 0;
				$host{status} ="o"; # original status; not modified
			}
			elsif ($in_vhost) {
				if (/ServerName\s+(\S+)/) {
					$host{name} = $1;
					$host{geo_flag} = 0;
				}
				elsif (/ProxyPass\s+\/\s+https?:\/\/\S+:(\d+)\//) {
					$host{port} = $1;
				}
				elsif  (/ESIDebugging\Won/i) {
					$host{debug_flag} = 1;
				}
				elsif (/GEO\s+(.*)/) {
					$host{geo_flag} = 1;
					$host{geo_string} = "GEO " . $1;
				}
			}
		}
		close CONFIG_FILE;
		if (!$host{name}) {
			print "unable to detect origin server name in $map_file\n";
		}
		elsif (!$host{port}) {
			print "unable to detect origin server port in $map_file\n";
		}
		else {
			push @user_input, { %host };
		}
	}
	
    return @user_input;
}

sub get_settings {
	
    my @user_input = ();
    my %host = ( port => 80, port2 => 81, name => "localhost" );
    my $in_vhost = 0;
    my ($geo_string, $geo_flag);
    $geo_flag = 0;
	
    my($config_file) = "$ETSHome/conf/esi.conf";
	
    open(CONFIG_FILE, "< $config_file")  || die "Can not open $config_file: $!\n";
    while (<CONFIG_FILE>) {
		
		if (/Listen\W+(\d+)/) {
			if ( !$host{port}) {
				$host{port} = $1; # esi_port
			}
			else {
				$host{port2} = $1; # esi_port2
			}
		}
		elsif(/^<VirtualHost\s+\*\:(\d+)>$/) {
			$in_vhost = 1;
		}
		elsif (/^<\/VirtualHost>$/) {
			$in_vhost = 0;
			$host{status} ="o"; # original status; not modified
		}
		elsif ($in_vhost) {
			
			if (/ServerName\s(\w+)/) {
				$host{name} = $1;
				$host{geo_flag} = 0;
			}
			elsif  (/ESIDebugging\Won/i) {
				$host{debug_flag} = 1;
			}
			elsif (/GEO\s+(.*)/) {
				
				$host{geo_flag} = 1;
				$host{geo_string} = "GEO " . $1;
				#                %geo = parse_geo_string($host{geo_string});
			}
		}
	}
	
    close CONFIG_FILE;
	push @user_input, { %host };

    return get_map_settings( @user_input );
}


#########################################################################
# display_configs: A function that displays current httpd.conf file
#                  configuration, then prompt the user for new values
#

sub display_configs {
    my @user_input = @_;
    my @hosts = ();
	
    shift @_;#user_input;
    @hosts = @_;
	
    print "\nCurrent settings for ETS to be written to $ETSHome/conf/esi.conf:\n"
		. "\t1)  ETS port:              $user_input[0]{port}\n"
		. "\t2)  Local virtual host:    $user_input[0]{name}:$user_input[0]{port2}\n"
		. "\t3)  Origin hosts: \n";
	
    display_origin_hosts(@hosts);
	
	if ( $is_reconfig ) {
		print "\ts)  Save changes\n"
		. "\te)  Exit without changing ETS\n\n";
	}
	else {
		print "\ti)  Install ETS\n"
		. "\te)  Exit without installing ETS\n\n";
	}
}

#########################################################################
# reconfig_prompt: A function that prompts user to enter paramteres values
# to modify httpd.conf file.
#

sub reconfig_prompt {
    my(@user_input) = @_;
	
    my($vhost_string) = "origin host";
    my($vhost_port_string) = "origin port";
    my($ETS_port_string) = "ETS port";
    my($debug_flag_string) = "response. Must be on or off";
    my($prefix_string) = "installation directory";
    
	
    while (1) {
		display_configs(@user_input);
		if (!$is_reconfig) {
			print "Please select an option to modify, \"i\" to install ETS or \"e\" to exit \nETS install program [1|2|3|i|e]: ";
		} else {
            print "Please select an option to modify, \"s\" to save changes or \"e\" to exit \nwithout saving [1|2|3|s|e]: ";
		}
		
		$answer = <STDIN>;
		chomp($answer);
		
		if ($answer eq "1") {
			print "\nETS port [$user_input[0]{port}]: ";
			my $esi_port = <STDIN>;
			chomp($esi_port);
			
			if ($esi_port ne "") {
				$user_input[0]{port}  = $esi_port;
			}
		}
		elsif ($answer eq "2") {
			print "\nETS local virtual hostname [$user_input[0]{name}]: ";
			my $name = <STDIN>;
			chomp($name);
			if ($name ne "") {
				$user_input[0]{name} = $name;
			}
			print "\nETS local virtual port [$user_input[0]{port2}]: ";
			my $port2 = <STDIN>;
			chomp($port2);
			if ($port2 ne "") {
				$user_input[0]{port2} = $port2;
			}
		}
		elsif ($answer eq "3") {
			print "\nVirtual origin hosts:\n\n ";
			@user_input = hosts_prompt(\%geo, @user_input);
		}
		elsif ($answer eq "s" && $is_reconfig) {
			print "\nConfiguring ETS....\n\n";
			last;
		}
		elsif ($answer eq "e") {
			print "\nExiting ETS configuration....\n";
			exit;
		}
		elsif ($answer eq "i" && !$is_reconfig) {
			print "\nInstalling ETS....\n";
			last;
		}
		else {
			print "\nInvalid selection....\n  ";
		}
    }
	return @user_input;
}

#########################################################################
# install_prompt: Displays messagses to input origin host, origin host httpd
#              port and mod-esi httpd port.
# Output     : returns an array that contain the user input.
#

sub install_prompt {
    my(@user_input) = @_;
    my @origin_hosts_list;
    my $esi_port;
	
    my %ets_host = ();
    $ets_host{prefix} = $ETSHome;
    $config_file = "$ETSHome/conf/esi.conf";
	
    #defaults
    $def_esi_port = "80";
    $ets_host{port} = get_input($def_esi_port, "Please type the ETS port",
		"What port should ETS listen on?  Normally this would " .
		"be the port that\nthe origin server is listening on.\n\n");
    $ets_host{is_installed} = 1;
	
    push @user_input, { %ets_host };
	
    @origin_hosts_list = initial_hosts_prompt($ETSHome, %geo);
	
    foreach  $host (@origin_hosts_list) {
		
		push @user_input, $host ;
    }
	
	return @user_input;
}

#########################################################################
# install_bindist: A function that untars and unzips the pre-built apache server.
#         The zipped file should be available in the current directory.
# input : The path to the installation directory (prefix)
# output: A pre-built apache server that is configured to load esi module.
#

sub install_bindist {
    my($answer) = "";
    my($here) =  getcwd();
	
    my($ESIInstaller_path) = $0;
	
    # replace ~ with correct home directory
    if ($ESIInstaller_path =~ /\~/) {
        $ESIInstaller_path = s/\~/$home/;
    }
	
    if ($ESIInstaller_path =~ /(.*)\/$esi_installer/) {
		$ESIInstaller_path = $1;
    } elsif ($ESIInstaller_path =~ /^[^\/]/ ) {
		$ESIInstaller_path =~ s/$esi_installer//;
        $ESIInstaller_path = $here .  "/" . $ESIInstaller_path ;
	}
	
	if (-x "$ETSHome/bin/apachectl") {
		system "$ETSHome/bin/apachectl stop 1>/dev/null 2>&1";
		
		if (-e "${ETSHome}.old") {
			system "rm -rf ${ETSHome}.old";
		}
	}
	
	chdir("$ESIInstaller_path/$files") || die "Can not cd to $files: $!\n";
	system ("$install_bindist $ETSHome");# || die "Can not execute install script: $!\n";
}

#########################################################################
# start_server: To start the server upon successfull installation,
#               or points the user to read technical docs
#               for furather details
#

sub start_server {
    my($answer) = "";
    my($test) = "testfile";
    my($started)= "";
	
    if ( !$is_reconfig ) {
        print "\nETS was successfully installed....\n\n";
        while (1) {
			print "Do you want to start the server? \"y\" or \"n\" [y]: ";
			$answer = <STDIN>;
			chomp($answer);
			
			if ($answer eq "y" || $answer eq "yes" || $answer eq "") {
				print "\nStarting the server....\n";
				my $rc = system ("$ETSHome/bin/apachectl stop 1>/dev/null 2>&1");
				$rc = system ("$ETSHome/bin/apachectl start");
				if ( $rc != 0 ) {
					print "\nUnable to start ETS.... \n"
						. "For further information, please check $ETSHome/logs/error_log\n\n";
				}
				else {
					print "\nETS has successfully been started....\n\n";
				}
				success_message($ETSHome, $esi_config_script);
				last;
			}
			elsif ($answer eq "n" || $answer eq "no") {
				success_message($ETSHome, $esi_config_script);
				last;
			}
			else {
				print "\nInvalid response....\n\n";
			}
		}
		
    } else {
		while (1) {
            print "Do you want to restart the server? \"y\" or \"n\" [y] ";
			$answer = <STDIN>;
            chomp($answer);
			
            if ($answer eq "y" || $answer eq "yes" || $answer eq "") {
				print "\nRestarting the server....\n";
				my $rc = system ("$ETSHome/bin/apachectl restart");
				if ( $rc != 0 ) {
					print "\nUnable to restart the server.... \nFor further information, please check $ETSHome/logs/error_log\n";
					print "\nTo apply the new configuration, please restart ETS by running the command: \n";
					print "$ETSHome/bin/apachectl restart\n\n";
				}
				else {
					print "\nETS has successfully been reconfigured and restarted....\n\n";
				}
				last;
			}
			elsif ($answer eq "n" || $answer eq "no") {
				print "\nETS has successfully been reconfigured....\n";
				print "\nTo apply the new configuration, please restart ETS by running the command: \n";
				print "$ETSHome/bin/apachectl restart\n\n";
				last;
			}
			else {
				print "\nInvalid response....\n\n";
			}
        }
    }
}





