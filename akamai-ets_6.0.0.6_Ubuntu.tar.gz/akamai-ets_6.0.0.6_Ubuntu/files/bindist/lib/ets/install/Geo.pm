#!/usr/bin/perl -w

use strict;

my $original_geo_string = "georegion=246,country_code=US,region_code=CA,city=SANJOSE,dma=807,pmsa=7400,areacode=408,county=SANTACLARA,fips=06085,lat=37.3353,long=-121.8938,timezone=PST,network_type=dialup";



sub parse_geo_string {
    my ($geo_string) = shift;
    my (%geo, $field);
    $geo_string = $original_geo_string if (!$geo_string);

    $geo_string =~ s/GEO\s//;

    my($georegion, $country_code, $region_code, $city, $dma, $pmsa, $areacode, $county, $fips, $lat, $long, $timezone, $network_type);

    my(@geo_ary) = split(/,/, $geo_string);

    foreach $field (@geo_ary) {
	if($field =~ /(.*)=(.*)/) {
	    $geo{$1} = $2 ;
	} 
    }

    return %geo;
}

sub display_geo_menu {
#    my($config_path) = shift;

    my(%geo) = @_;


    print "\nGEO information: \n";# to be written to $config_path:\n";

    print "\n\t1)  georegion:      "; 
    print "$geo{'georegion'}" if (defined $geo{'georegion'});
    print "\n\t2)  country_code:   ";
    print "$geo{'country_code'}" if (defined $geo{'country_code'});
    print "\n\t3)  region_code:    ";
    print "$geo{'region_code'}" if (defined $geo{'region_code'});
    print "\n\t4)  city:           ";
    print "$geo{'city'}" if (defined $geo{'city'});
    print "\n\t5)  dma:            ";
    print "$geo{'dma'}" if (defined $geo{'dma'});
    print "\n\t6)  pmsa:           ";
    print "$geo{'pmsa'}" if (defined $geo{'pmsa'});
    print "\n\t7)  areacode:       ";
    print "$geo{'areacode'}" if (defined $geo{'areacode'});
    print "\n\t8)  county:         ";
    print "$geo{'county'}" if (defined $geo{'county'});
    print "\n\t9)  fips:           ";
    print "$geo{'fips'}" if (defined $geo{'fips'});
    print "\n\t10) lat:            ";
    print "$geo{'lat'}" if (defined $geo{'lat'});
    print "\n\t11) long:           ";
    print "$geo{'long'}" if (defined $geo{'long'});
    print "\n\t12) timezone:       ";
    print "$geo{'timezone'}" if (defined $geo{'timezone'});
    print "\n\t13) network_type:   ";
    print "$geo{'network_type'}" if (defined $geo{'network_type'});
    print "\n";
}

sub display_geo_submenu {
#    my($config_path) = shift;
    my %geo = @_;

print "\n\n\t\t-  georegion:      ";
print "$geo{'georegion'}" if (defined $geo{'georegion'});
print "\n\t\t-  country_code:   ";
print "$geo{'country_code'}" if (defined $geo{'country_code'});
print "\n\t\t-  region_code:    ";
print "$geo{'region_code'}" if (defined $geo{'region_code'});
print "\n\t\t-  city:           ";
print "$geo{'city'}" if (defined $geo{'city'});
print "\n\t\t-  dma:            ";
print "$geo{'dma'}" if (defined $geo{'dma'});
print "\n\t\t-  pmsa:           ";
print "$geo{'pmsa'}" if (defined $geo{'pmsa'});
print "\n\t\t-  areacode:       ";
print "$geo{'areacode'}" if (defined $geo{'areacode'});
print "\n\t\t-  county:         ";
print "$geo{'county'}" if (defined $geo{'county'});
print "\n\t\t-  fips:           ";
print "$geo{'fips'}" if (defined $geo{'fips'});
print "\n\t\t-  lat:            ";
print "$geo{'lat'}" if (defined $geo{'lat'});
print "\n\t\t-  long:           ";
print "$geo{'long'}" if (defined $geo{'long'});
print "\n\t\t-  timezone:       ";
print "$geo{'timezone'}" if (defined $geo{'timezone'});
print "\n\t\t-  network_type:   ";
print "$geo{'network_type'}" if (defined $geo{'network_type'});
print "\n\n";
}

sub geo_prompt {
#    my($config_path) = shift;    
    my %geo = @_;


    my $georegion_string = "\ngeoregion: ";
    my $country_code_string = "\ncountry_code: ";
    my $region_code_string = "\nregion_code: ";
    my $city_string = "\ncity: ";
    my $dma_string = "\ndma: ";
    my $pmsa_string = "\npmsa: ";
    my $areacode_string = "\nareacode: ";
    my $county_string = "\ncounty: ";
    my $fips_string = "\nfips: ";
    my $lat_string = "\nlat: ";
    my $long_string = "\nlong: ";
    my $timezone_string = "\ntimezone: ";
    my $network_type_string = "\nnetwork_type: ";

    my $answer = "";
    
    while (1) {
       display_geo_menu(%geo);
#       display_geo_menu($config_path, %geo);

       print "\nPlease select an option to modify [1-13], or enter \"a\" to accept settings: ";
       $answer = <STDIN>;
       chomp($answer);

       if($answer eq "1") {
	  print $georegion_string;
	  $geo{'georegion'} = <STDIN>;
	  chomp  $geo{'georegion'};
       } elsif($answer eq "2") {
	   print $country_code_string;
	   $geo{'country_code'} = <STDIN>;
	       chomp $geo{'country_code'};
       } elsif($answer eq "3") {
           print $region_code_string;
	   $geo{'region_code'} = <STDIN>;
	   chomp $geo{'region_code'};
       } elsif($answer eq "4") {
           print $city_string;
	   $geo{'city'}= <STDIN>;
	   chomp $geo{'city'};
       } elsif($answer eq "5") {
           print $dma_string;
	   $geo{'dma'} = <STDIN>;
	   chomp $geo{'dma'};
       } elsif($answer eq "6") {
           print $pmsa_string;
	   $geo{'pmsa'} = <STDIN>;
	   chomp $geo{'pmsa'};
       } elsif($answer eq "7") {
           print $areacode_string;
	   $geo{'areacode'} = <STDIN>;
	   chomp $geo{'areacode'};
       } elsif($answer eq "8") {
           print $county_string;
	   $geo{'county'} = <STDIN>;
	   chomp $geo{'county'};
       } elsif($answer eq "9") {
           print $fips_string;
           $geo{'fips'} = <STDIN>;
	   chomp $geo{'fips'};
       } elsif($answer eq "10") {
           print $lat_string;
	   $geo{'lat'} = <STDIN>;
	   chomp $geo{'lat'};
       } elsif($answer eq "11") {
           print $long_string;
	   $geo{'long'} = <STDIN>;
	   chomp $geo{'long'};
       } elsif($answer eq "12") {
           print $timezone_string;
	   $geo{'timezone'} = <STDIN>;
	   chomp $geo{'timezone'};
       } elsif($answer eq "13" ) {
           print $network_type_string;
	   $geo{'network_type'} = <STDIN>;
	   chomp $geo{'network_type'};

       } elsif ($answer eq "a") {
           return %geo;

       } else {
           print "\nInvalid selection....\n ";
       }
    }
}

sub build_geo_string {
    my %geo = @_;

    my $geo_string = "GEO ";

    if (defined $geo{'georegion'} && $geo{'georegion'} ne "") {
    $geo_string .=
        "georegion=$geo{'georegion'}";
    }

    if (defined $geo{'country_code'} && $geo{'country_code'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "country_code=$geo{'country_code'}";
    }

    if (defined $geo{'region_code'} && $geo{'region_code'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "region_code=$geo{'region_code'}";
    }

    if (defined $geo{'city'} && $geo{'city'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);

	$geo_string .= "city=$geo{'city'}";
    }

    if (defined $geo{'dma'} && $geo{'dma'} ne "") {

	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "dma=$geo{'dma'}";
    }

    if (defined $geo{'pmsa'} && $geo{'pmsa'} ne "") {

	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "pmsa=$geo{'pmsa'}";
    }

    if (defined $geo{'areacode'} && $geo{'areacode'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "areacode=$geo{'areacode'}";
    }

    if (defined $geo{'county'} && $geo{'county'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "county=$geo{'county'}";
    }

    if (defined $geo{'fips'} && $geo{'fips'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "fips=$geo{'fips'}";
    }

    if (defined $geo{'lat'} && $geo{'lat'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "lat=$geo{'lat'}";
    }

    if (defined $geo{'long'} && $geo{'long'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "long=$geo{'long'}";
    }

    if (defined $geo{'timezone'} && $geo{'timezone'} ne "") { 
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "timezone=$geo{'timezone'}";
    }

    if (defined $geo{'network_type'} && $geo{'network_type'} ne "") {
	$geo_string .= "," if ($geo_string =~ /GEO\s.*=.*/);
	$geo_string .= "network_type=$geo{'network_type'}";
    }

    return $geo_string;
}







