#!/usr/bin/perl -w
use Data::Dumper;
use Getopt::Long;
use InstallUtils;

use constant { TRUE => 1, FALSE => 0 };

sub usage()
{
    print STDERR <<'END_USAGE';
Usage: ./ets-cli-config --local_hostname=LOCAL_HOSTNAME --ets_port=PORT --sandbox_port=SANDBOX_PORT [additional args]
--local_hostname=<hostname> - default hostname for the ESI server and sandbox server to listen on
--ets_port=<port> - port for the ESI server to listen on
--sandbox_port=<port> - port for the sandbox (local non-ESI origin) to listen on
--remote_origin <hostname:port> - hostname and port to use for an additional remote/upstream origin
--debug <hostname> - enable ESI debugging for that hostname
--geo <hostname:settings> - enable Edgescape for a hostname via mock data; sample below
Sample GEO flag: www.akamai.com:georegion=246,country_code=US,region_code=CA,city=SANJOSE,dma=807,pmsa=7400,areacode=408,county=SANTACLARA,fips=06085,lat=37.3353,long=-121.8938,timezone=PST,network_type=dialup
END_USAGE
}

my $ets_port;
my $local_hostname;
my $sandbox_port;
my @remote_origins;
my @geo_settings;
my @debug_settings;
my $size_config;

GetOptions (
    "local_hostname=s" => \$local_hostname, 
    "ets_port=i" => \$ets_port,
    "sandbox_port=i" => \$sandbox_port,
    "remote_origin=s" => \@remote_origins,
    "geo=s" => \@geo_settings,
    "debug=s" => \@debug_settings,
    "esi_limit=i" => \$size_config
) or die("Error in args.");

if (!defined $local_hostname) {
    die("local_hostname is required.");
}
if (!defined $ets_port) {
    die("ets_port is required.");
}
if (!defined $sandbox_port) {
    die("sandbox_port is required.");
}

my %origins_map;

$origins_map{$local_hostname} = {
    name => $local_hostname,
    port => $ets_port,
    port2 => $sandbox_port,
    status => ""
};

foreach $remote_origin_str (@remote_origins) {
    @remote_origin = split(/:/, $remote_origin_str);
    if (scalar(@remote_origin) != 2) {
        die("Origins must be provided in host:port format. Failed to parse $remote_origin_str");
    }

    $origins_map{$remote_origin[0]} = { 
        name => $remote_origin[0],
        port => $remote_origin[1],
        status => ""
    };
}

foreach $geo_str(@geo_settings) {
    my $enable_geo = FALSE;
    @geo_setting = split(/:/, $geo_str);
    if (scalar(@geo_setting) < 2) {
        die("Geo settings must be provided in host:setting1,setting2... format. Failed to parse $geo_str");
    }

    my $host = $geo_setting[0];
    if (!exists $origins_map{$host}) {
        die("Host $host not defined as an origin but had a geo setting.");
    }

    $origins_map{$host}{geo_flag} = "on";
    $origins_map{$host}{geo_string} = "GEO $geo_setting[1]";
}

foreach $debug_enabled_host(@debug_settings) {
    if (!exists $origins_map{$debug_enabled_host}) {
        die("Host $debug_enabled_host not defined as an origin but had a debug setting.");
    }
    
    $origins_map{$debug_enabled_host}{debug_flag} = "on";
}

if (defined $size_config) {
    foreach $host (keys %origins_map) {
        $origins_map{$host}{apache_config} = "MetaData dca-max-output-size $size_config";
    }
}

# change the hash into the array that fix_configs expects
my @origins;
$origins[0] = $origins_map{$local_hostname};
delete $origins_map{$local_hostname};
splice @origins, 1, 0, values %origins_map;

print "Using settings:\n";
print Dumper(\@origins);

fix_configs("/opt/akamai-ets", @origins);