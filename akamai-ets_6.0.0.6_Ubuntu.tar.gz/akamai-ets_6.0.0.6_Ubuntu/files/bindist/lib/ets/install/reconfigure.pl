#!/usr/bin/perl -w
use strict;

use Data::Dumper;
use Getopt::Long;
use InstallUtils;

use constant { TRUE => 1, FALSE => 0};
my $DEFAULT_GEO = "georegion=246,country_code=US,region_code=CA,"
    . "city=SANJOSE,dma=807,pmsa=7400,areacode=408,county=SANTACLARA,fips=06085,"
    . "lat=37.3353,long=-121.8938,timezone=PST,network_type=dialup";
my $GEO_STRING_EXAMPLE = "www.example.com:$DEFAULT_GEO";
my $SCRIPT_NAME = "docker run -ti akamaiesi/ets-docker";

sub logo() {
    print <<'END_LOGO'
    ___    __                         _    _________________
   /   |  / /______ _____ ___  ____ _(_)  / ____/_  __/ ___/
  / /| | / //_/ __ `/ __ `__ \/ __ `/ /  / __/   / /  \__ \ 
 / ___ |/ ,< / /_/ / / / / / / /_/ / /  / /___  / /  ___/ / 
/_/  |_/_/|_|\__,_/_/ /_/ /_/\__,_/_/  /_____/ /_/  /____/  

END_LOGO
}

sub usage() {
    print STDERR <<END_USAGE
Usage: 
    \$ $SCRIPT_NAME [args]

    For additional documentation, see the README at https://hub.docker.com/r/akamaiesi/ets-docker/ .

Options:
    --remote_origin <hostname[:port]> or -r <hostname[:port]>
        Hostname and port (default 80) to use for an additional remote/upstream origin.

    --debug <hostname> or -d <hostname> 
        Enable ESI debugging for that hostname.
    
    --geo <hostname:[settings|off]> or -g <hostname:[settings|off]>
        Set Edgescape values for a hostname via mock data, or disable it (off). To set settings for the ESI sandbox, use the hostname localhost.

        Example settings string: $GEO_STRING_EXAMPLE

    --help or -h
        Show this message.

Examples:

    \$ $SCRIPT_NAME -d localhost -g localhost:off
        Enables ESI debugging and disables Edgescape for the ESI sandbox.

    \$ $SCRIPT_NAME -r yoursite1.example.com:443 -r yoursite2.example.com -d yoursite1.example.com -g yoursite2.example.com:off
        Configures ETS to be able to serve ESI-enabled traffic for two different origins (yoursite1.example.com and yoursite2.example.com).
        ESI debugging is enabled for yoursite1.example.com, and Edgescape is disabled for yoursite2.example.com.

    \$ $SCRIPT_NAME --remote_origin www.example.com:443 --geo www.example.com:city=TORONTO
        Configures ETS to be able to serve ESI-enabled traffic for www.example.com, with Edgescape settings that only specify a city.

Defaults (values used if not specified):
    --geo <hostname>:$DEFAULT_GEO
    (Edgescape is on by default for each remote origin.)

END_USAGE
}

sub print_configs {
    my $esi_sandbox_settings_ref = shift;
    my $remote_origin_settings_ref = shift;
    my %esi_sandbox_settings = %{$esi_sandbox_settings_ref};
    my %remote_origin_settings = %{$remote_origin_settings_ref};

    print_config($esi_sandbox_settings_ref, TRUE);

    foreach my $remote_origin (values %remote_origin_settings) {
        print_config($remote_origin, FALSE);
    }
}

sub print_config {
    my $settings_ref = shift;
    my $is_esi_and_sandbox_settings = shift;
    my %settings = %{$settings_ref};

    if ($is_esi_and_sandbox_settings) {
        print "ESI and Sandbox settings:\n";
        printf("    Hostname:        %s\n", $settings{name});
        printf("    ESI port:        %s\n", $settings{port});
        printf("    Sandbox port:    %s (ESI off; default ESI origin)\n", $settings{port2});
    } else {
        printf("Remote origin %s settings:\n", $settings{name});
        printf("    Hostname:        %s\n", $settings{name});
        printf("    Upstream port:   %s\n", $settings{port});
    }
    printf("    ESI debugging:   %s\n", ($settings{debug_flag}? $settings{debug_flag} : "off") );
    
    if (exists $settings{geo_flag}) {
        print "    GEO/Edgescape:   on\n";
        print_geo_settings($settings{geo_string});
    } else {
        print "    GEO/Edgescape:   off\n";
    }
    print "\n";
}

sub print_geo_settings {
    my $geo_string = shift;
    $geo_string =~ s/^GEO //;
    $geo_string =~ s/^.+?://;
    my @geo_settings = split(/,/, $geo_string);

    foreach my $geo_pair(@geo_settings) {
        my ($key, $value) =  split(/=/, $geo_pair);
        printf("      %-12s = %s\n", $key, $value);
    }
}

sub show_error_and_exit {
    my $text = shift;
    print $text;
    exit 2;
}

my $ets_port = 80;
my $local_hostname = "localhost";
my $sandbox_port = 81;
my @remote_origins;
my @geo_settings;
my @debug_settings;
my $size_config;
my $help;

GetOptions (
    "local_hostname=s" => \$local_hostname, 
    "ets_port=i" => \$ets_port,
    "sandbox_port=i" => \$sandbox_port,
    "remote_origin=s" => \@remote_origins,
    "geo=s" => \@geo_settings,
    "debug=s" => \@debug_settings,
    "page_size_limit=i" => \$size_config,
    "help" => \$help
) or do {
    usage();
    show_error_and_exit("Error in arguments.");
};

if ($help) {
    usage();
    exit 1;
}

my %origins_map;

$origins_map{$local_hostname} = {
    name => $local_hostname,
    port => $ets_port,
    port2 => $sandbox_port,
    geo_flag => "on",
    geo_string => "GEO $DEFAULT_GEO",
    status => ""
};

foreach my $remote_origin_str (@remote_origins) {
    my @remote_origin = split(/:/, $remote_origin_str);
    if (scalar(@remote_origin) < 1 || scalar(@remote_origin) > 2) {
        show_error_and_exit("Origins must be provided in host or host:port format."
            . "(Port defaults to 80 if not specified.) Failed to parse $remote_origin_str");
    }

    $origins_map{$remote_origin[0]} = { 
        name => $remote_origin[0],
        port => $remote_origin[1]? $remote_origin[1] : "80",
        geo_flag => "on",
        geo_string => "GEO $DEFAULT_GEO",
        status => ""
    };
}

foreach my $geo_str(@geo_settings) {
    my $enable_geo = FALSE;
    my @geo_setting = split(/:/, $geo_str);
    if (scalar(@geo_setting) < 2) {
        show_error_and_exit("Geo settings must be provided in host:setting1,setting2... format. Failed to parse $geo_str");
    }

    my $host = $geo_setting[0];
    if (!exists $origins_map{$host}) {
        show_error_and_exit("Host $host not defined as an origin but had a geo setting.");
    }

    if ($geo_setting[1] eq "off") {
        delete $origins_map{$host}{geo_flag};
    } else {
        $origins_map{$host}{geo_flag} = "on";
        $origins_map{$host}{geo_string} = "GEO $geo_setting[1]";
    }
}

foreach my $debug_enabled_host(@debug_settings) {
    if (!exists $origins_map{$debug_enabled_host}) {
        show_error_and_exit("Host $debug_enabled_host not defined as an origin but had a debug setting.");
    }
    
    $origins_map{$debug_enabled_host}{debug_flag} = "on";
}

if (defined $size_config) {
    foreach my $host (keys %origins_map) {
        $origins_map{$host}{apache_config} = "MetaData dca-max-output-size $size_config";
    }
}

# change the hash into the array that fix_configs expects
my @origins;
$origins[0] = $origins_map{$local_hostname};
delete $origins_map{$local_hostname};
splice @origins, 1, 0, values %origins_map;

logo();
print "For usage information, run \$ $SCRIPT_NAME -h\n\n";
print_configs($origins[0], \%origins_map);

fix_configs("/opt/akamai-ets", @origins);