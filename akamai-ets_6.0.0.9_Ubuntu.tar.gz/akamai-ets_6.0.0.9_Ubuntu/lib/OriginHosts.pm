#!/usr/bin/perl -w

use strict;
use InstallUtils;
use Geo;

my($true) = "1";
my($false) = "";


sub config_hosts {
	
}


sub initial_hosts_prompt {
    my $prefix = shift;
    my %geo = @_;
    my($origin_host_help_string) = "ETS needs to know how to contact the " .
	"origin server, which is the \nserver that actually serves the content being " .
	"tested.  ETS transparently \nforwards requests to the origin " .
	"server, allowing clients to make requests \nto ETS as if it was the " .
	"origin server.\n\n";
    my($origin_host_string) = "Please type the origin server's hostname";
	
    my($origin_port_help_string) = "";
    my($origin_port_string) = "Please type the origin servers's port";
	
    my($debug_flag_help_string) = "The ESI Development Tool (ESID) provides ".
	"a way to debug web pages \nthat contain ESI code.\n\n";
	
    my($debug_string) = "Set ESI Debugging (ESID) \"on\" or \"off\"";
	
    my $geo_prompt_string = "Configure GEO settings? \"y\" or \"n\"";
    my $geo_flag_help_string = "Test settings for the GEO variable may be set " .
	"to test ESI content which \nuses the EdgeScape service.\n\n";
	
    # default values
    my $def_origin_host = "localhost";
    my $def_origin_port = "81";
    my($def_debug_flag) = "off";
    my $def_geo_flag = "n";
	
    my ($origin_host, $origin_port, $debug_flag, $geo_flag);
    my $geo_string = "";
    my $host_count = 0;
    my %host = ();
    my @hosts_list;
    my $answer = "y";
	
    while($true) {
		if($answer eq "y" || $answer eq "Y") {
			if($host_count == 0) {
				$origin_host = get_input($def_origin_host, $origin_host_string,
				$origin_host_help_string);
			} else {
				$origin_host = get_input($def_origin_host, $origin_host_string,
				"");
			}
			
			while ($true) {
				
				if ($origin_host =~ /(.*):(\d+)/) {
					$host{name} = $1;
					$host{port} = $2;
					last;
				} elsif ($origin_host =~ /(.*):(.*)/) {
					print "\nInvalid host. Please re-type....\n";
					$origin_host = get_input($def_origin_host,
					$origin_host_string, "");
				} else {
					
					$host{name} = $origin_host;
					if($host_count == 0) {
						$origin_port = get_input($def_origin_port,
						$origin_port_string,
						$origin_port_help_string);
						
					} else {
						$origin_port = get_input($def_origin_port,
						$origin_port_string, "");
						
					}
					$host{port} = $origin_port;
					
					last;
				}
			}
			
			while($true) {
				if($host_count == 0) {
					$debug_flag = get_input($def_debug_flag, $debug_string,
					$debug_flag_help_string);
				} else {
					$debug_flag = get_input($def_debug_flag, $debug_string,
					"");
				}
				if($debug_flag eq "on" || $debug_flag eq "off") {
					
					$host{debug_flag} = ( $debug_flag eq "on" );
					last;
				} else {
					print "\nInvalid response. Must be \"on\" or \"off\"....\n";
				}
			}
			
			while($true) {
				if($host_count == 0) {
					$geo_flag = get_input($def_geo_flag, $geo_prompt_string,
					$geo_flag_help_string);
				} else {
					$geo_flag = get_input($def_geo_flag, $geo_prompt_string,
					"");
				}
				
				if($geo_flag eq "y" || $geo_flag eq "n" || $geo_flag eq "Y" || $geo_flag eq "N") {
					
					# use true or false instead of y, n
					if ($geo_flag eq "n" || $geo_flag eq "N") {
						$geo_flag = $false;
						
					} elsif ($geo_flag eq "y" || $geo_flag eq "Y") {
						$geo_flag = $true;
					}
					
					$geo_string = build_geo_string(%geo) if ($geo_flag);
					
					$host{geo_flag} = $geo_flag;
					$host{geo_string} = $geo_string;
					$geo_string = "";
					last;
				} else {
					print "\nInvalid response. Must be \"y\" or \"n\"....\n";
				}
			}
			
			$host{count} = $host_count++;
			$host{status} = "o";
			
			%host = config_host($#hosts_list+2, %host);
			
			push @hosts_list, { %host };
			
			undef %host;
			
			print "\n\nAdd a Origin Host? \"y\" or \"n\" [n]: ";
            $answer = <STDIN>;
            chomp $answer;
			
		} elsif ($answer eq "n" || $answer eq "N" || $answer eq "") {
			last;
			
		} else {
			print "\nInvalid value. Must be \"y\" or \"n\"....\n";
			print "\n\nAdd a Origin Host? \"y\" or \"n\" [n]: ";
			$answer = <STDIN>;
			chomp $answer;
			
        }
    } # outer while loop
	
    return @hosts_list;
} # initial_hosts_prompt


sub display_host_menu {
    my $hosts_count = shift;
	
    my %host =  @_;
    my $debug_display = $host{debug_flag}? "on" : "off";
	
    print "\n\nCurrent settings for origin host \"$host{name}\":\n\n";
    print "\t1)  Origin host:            $host{name}
	\t2)  Origin port:            $host{port}
	\t3)  ESI Debugging (ESID):   $debug_display
	\t4)  GEO settings:           ";
    if ($host{geo_flag} ) {
        my %geo = parse_geo_string($host{geo_string});
        display_geo_submenu(%geo);
		
    } else {
        print "None\n";
    }
	
    print "\ta)  Accept settings\n";
	
	print "\td)  Delete host\n\n"
	
}

sub display_origin_hosts {
	
    my @hosts = @_;
    my $host;
	
    print "\n";
    if ($#hosts >= 0) {
		
		foreach $host (@hosts) {
			print "\t\t-  $host->{name}:$host->{port}\n" if ($host->{status} ne "d");
		}
    } else {
		print "\t\t-  None\n";
    }
	
    print "\n";
}


sub config_host {
    my $hosts_count = shift;
    my %host = @_;
	
    my %original_host = %host;
    my $answer;
	
    my %geo;
	
    my $origin_host_string = "origin host";
    my $origin_port_string = "origin port";
    my $debug_flag_string = "response. Must be on or off";
	
	
    while ($true) {
		display_host_menu($hosts_count, %host);
		print "Please select an option to modify host's settings, \"a\" to accept settings, or \"d\" \nto delete host [1|2|3|4|a|d]: ";
		$answer = <STDIN>;
		chomp $answer;
		
		if ($answer eq "1") {
			print "\nOrigin host: ";
			my $origin_host = <STDIN>;
			chomp($origin_host);
			
			if($origin_host ne "") {
				$host{name} = $origin_host;
				
			} else {
				print "\nInvalid $origin_host_string....\n";
			}
			$host{status} = "m";
			
		} elsif ($answer eq "2") {
			print "\nOrigin port: ";
			my $origin_port = <STDIN>;
			chomp($origin_port);
			if($origin_port ne "") {
				$host{port} = $origin_port;
				
			} else {
				print "\nInvalid $origin_port_string....\n";
			}
            $host{status} = "m";# modified
			
		} elsif ($answer eq "3") {
			print "\nESI Debugging (ESID) \"on\" or \"off\": ";
			my $debug_flag = <STDIN>;
			chomp($debug_flag);
			
			if($debug_flag eq "on" || $debug_flag eq "off") {
				$host{debug_flag} = ($debug_flag eq "on");
				
			} else {
				print "\nInvalid response. Must be on or off....\n";
			}
            $host{status} = "m"; # modified
		} elsif ($answer eq "4") {
			%geo = parse_geo_string($host{geo_string});
			
			%geo = geo_prompt(%geo);
			
			my  $geo_string = build_geo_string(%geo);
			
			if ($geo_string =~ /GEO\s\w/) {
				$host{geo_flag} = $true;
			} else {
				$host{geo_flag} = $false;
			}
			$host{geo_string} = $geo_string;
			$host{status} = "m"; # modified
			
        } elsif ($answer eq "a") {
			return %host;
			
        } elsif ($answer eq "d") {
			
            $host{status} = "d"; # original host
			return %host;
        } else {
			print "\nInvalide selection. Please re-type....\n\n";
		}
		
    }
}


sub display_hosts_menu {
	
    my @hosts = @_;
	
    my $host;
    my $count = 1;
	
    print "\n";
	
    foreach $host (@hosts) {
		if ($host->{status} ne "d") {
			print "\t$count)  $host->{name}:$host->{port}\n";
			++$count;
		}
	}
	
    print "\t+)  Add a host\n"
		. "\ta)  Accept changes\n";
	
    print "\nSelect a host to modify or delete, \"+\" to add host, or \"a\" to accept changes: ";
}


sub hosts_prompt {
	#    my $prefix = shift;
    my $geo = shift;
	
    my @user_input = @_;
    my @hosts = ();
    
    shift @_;
    my @all_hosts = @_;
	
    my $host = {};
	
    my $answer = "";
    my $int_answer = -1;
	
	
    while ($true) {
		undef @hosts ;
		my $position = 0;
		foreach $host (@all_hosts) {
			$host->{position} = $position++;
			
			if ($host->{status} ne "d") {
				push @hosts, $host;
				
			}
		}
		
		my $count = $#hosts;
		
		display_hosts_menu(@all_hosts);
		$answer = <STDIN>;
		chomp $answer;
		if($answer =~ /^\d(\d*)$/) {
			$int_answer = int($answer);
			
			if ($int_answer > 0 && $int_answer <= $count+1) {
				
				$host = $hosts[$int_answer - 1];
				%$host = config_host($count+1, %$host);
				
				$all_hosts[$host->{position}] = $host ;
				
			}
		} else {
			if ($answer eq "+") {
				$host = add_host($user_input[0]{install_flag}, %$geo);
				
				push @user_input, { %$host };
				push @all_hosts, { %$host };
				
			} elsif ($answer eq "a" ) {
				return @user_input;
				
			} else {
				print "\nInvalid selection\n\n";
			}
	    	
		}
    }
}


sub add_host {
    my $install_flag = shift;
    my %geo = @_;
	
    my %host= ();
	
    my $origin_host_string = "origin host";
    my $origin_port_string = "origin port";
	
    my $debug_flag_string = "response. Must be on or off";
	
    my $origin_port_prompt_string = "Please type the origin servers's port";
    my($debug_string) = "Set ESI Debugging (ESID) \"on\" or \"off\"";
    my $geo_prompt_string = "Configure GEO settings \"y\" or \"n\"?";
	
    my($def_origin_host) = "localhost";
	
    my($def_origin_port) = "80";
    my($def_debug_flag) = "off";
    my $def_geo_flag = "n";
	
	
	my $geo_string;
    my $geo_flag;
	
    while ($true) {
		print "\nPlease type origin host: ";
		my $origin_host = <STDIN>;
		chomp($origin_host);
		
		if($origin_host ne "") {
			$host{name} = $origin_host;
			last;
		} else {
			print "\nInvalid $origin_host_string....\n";
		}
    }
	
    while ($true) {
		my $origin_port =  get_input($def_origin_port, $origin_port_prompt_string, "");
		if($origin_port ne "") {
			$host{port} = $origin_port;
			last;
		} else {
			print "\nInvalid $origin_port_string....\n";
		}
    }
	
    while ($true) {
		
		my $debug_flag = get_input($def_debug_flag, $debug_string, "");
		
		if($debug_flag eq "on" || $debug_flag eq "off") {
			$host{debug_flag} = ( $debug_flag eq "on" );
			last;
		} else {
			print "\nInvalid response. Must be on or off....\n";
		}
    }
	
    while ($true) {
		
		$geo_flag = get_input($def_geo_flag, $geo_prompt_string, "");
		
		if($geo_flag eq "y" || $geo_flag eq "n" || $geo_flag eq "Y" || $geo_flag eq "N") {
			
            # use true or false instead of y, n
			if ($geo_flag eq "n" || $geo_flag eq "N") {
				$geo_flag = $false;
				
			} elsif ($geo_flag eq "y" || $geo_flag eq "Y") {
				$geo_flag = $true;
			}
			
			$geo_string = build_geo_string(%geo) if ($geo_flag);
			
			$host{geo_flag} = $geo_flag;
			$host{geo_string} = $geo_string;
			last;
		} else {
			print "\nInvalid response. Must be \"y\" or \"n\"....\n";
		}
		
    }
    if ($geo_flag) {
		%geo = geo_prompt(%geo);
		
		$geo_string = build_geo_string(%geo);
		
		if ($geo_string =~ /GEO\s\w/) {
			$host{geo_flag} = $true;
		} else {
			$host{geo_flag} = $false;
		}
    }
    
    $host{geo_string} = $geo_string;
	
    %host = config_host(2, %host);
	
    if ($install_flag) {
		$host{status} = "o";
    } else {
		$host{status} = "n";
    }
	
    return \%host;
	
}


