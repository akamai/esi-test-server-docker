#!/bin/sh
#
# Usage: install-bindist.sh [ServerRoot]
# This script installs the Apache binary distribution and
# was automatically created by binbuild.sh.
 
lmkdir()
{
  path=""
  dirs=`echo $1 | sed -e 's%/% %g'`
  mode=$2
 
  set -- ${dirs}
 
  for d in ${dirs}
  do
    path="${path}/$d"
    if test ! -d "${path}" ; then
      mkdir ${path}
      if test $? -ne 0 ; then
        echo "Failed to create directory: ${path}"
        exit 1
      fi
      chmod ${mode} ${path}
    fi
  done
}
 
lcopy()
{
  from=$1
  to=$2
  dmode=$3
  fmode=$4
 
  test -d ${to} || lmkdir ${to} ${dmode}
  (cd ${from} && tar -cf - *) | (cd ${to} && tar -xf -)
 
  if test "X${fmode}" != X ; then
    find ${to} -type f -print | xargs chmod ${fmode}
  fi
  if test "X${dmode}" != X ; then
    find ${to} -type d -print | xargs chmod ${dmode}
  fi
}
 
##
##  determine path to (optional) Perl interpreter
##
PERL=no-perl5-on-this-system
perls='perl5 perl'
path=`echo $PATH | sed -e 's/:/ /g'`
 
for dir in ${path} ;  do
  for pperl in ${perls} ; do
    if test -f "${dir}/${pperl}" ; then
      if `${dir}/${pperl} -v | grep 'version 5\.' >/dev/null 2>&1` ; then
        PERL="${dir}/${pperl}"
        break
      fi
    fi
  done
done
 
if [ .$1 = . ]
then
  SR=/usr/local/apache
else
  SR=$1
fi
echo "Installing binary distribution"
echo "into directory $SR ..."
lmkdir $SR 755
#lmkdir $SR/proxy 750
lmkdir $SR/logs 777
lcopy bindist/lib $SR/lib 755 644
lcopy bindist/include $SR/include 755 644
lcopy bindist/cgi-bin $SR/cgi-bin 750 750
lcopy bindist/bin $SR/bin 750 750
lcopy bindist/error $SR/error 750 750
lcopy bindist/htdocs $SR/htdocs 755 755
lcopy bindist/modules $SR/modules 750 750
lcopy bindist/share $SR/share 750 750
lcopy bindist/virtual $SR/virtual 755 755
if [ -d $SR/conf ]
then
  echo "[Preserving existing configuration files.]"
  cp bindist/conf/*.conf $SR/conf/
else
  lcopy bindist/conf $SR/conf 755 644
fi

# SEI: error cause its not checked in?
#cp ../ETS_4.8_Installation_Guide.pdf $SR
 
sed -e "s;^#!/.*;#!$PERL;" -e "s;\@prefix\@;$SR;" -e "s;\@sbindir\@;$SR/bin;" \
	-e "s;\@libexecdir\@;$SR/libexec;" -e "s;\@includedir\@;$SR/include;" \
	-e "s;\@sysconfdir\@;$SR/conf;" bindist/bin/apxs > $SR/bin/apxs
sed -e "s;^#!/.*;#!$PERL;" bindist/bin/dbmmanage > $SR/bin/dbmmanage
sed -e "s%SUBST_PREFIX_SUBST%$SR%" $SR/conf/httpd.conf.tmpl > $SR/conf/httpd.conf
sed -e "s%SUBST_PREFIX_SUBST%$SR%" bindist/conf/esi.conf.tmpl   > $SR/conf/esi.conf.tmpl
sed -e "s%SUBST_PREFIX_SUBST%$SR%" $SR/conf/asis.conf.tmpl  > $SR/conf/asis.conf
sed -e "s%HTTPD=.*$%HTTPD=\"$SR/bin/httpd\"%" bindist/bin/apachectl > $SR/bin/apachectl

echo


